function createChicken() {
  var chicken = document.createElement("img");
  chicken.src = "https://vignette.wikia.nocookie.net/yandere-simulator-fanon/images/0/03/D583b6ce056ba98e71485fb2f08b5770.png/revision/latest?cb=20180716023745";
  chicken.style.position = "absolute";
  chicken.style.height = "100px";
  return chicken;
}
var chicken_container = document.getElementById("chicken-container");

chicken_container.addEventListener("click", () => {
  console.log(Math.floor(Math.random() * screen.width).toString + "px");
  var chicken = createChicken();
  console.log(chicken.scrollHeight);
  chicken.style.top = Math.floor(Math.random() * chicken_container.offsetHeight - chicken.scrollHeight).toString() + "px";
  chicken.style.left = Math.floor(Math.random() * chicken_container.offsetWidth - chicken.scrollWidth).toString() + "px";
  chicken_container.appendChild(chicken);
}, false);